/* =========================================================
   PORTFOLIO — INTERAKSI (Vanilla JavaScript)
   ========================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------------------------------------------------
     1. TAHUN OTOMATIS DI FOOTER
  --------------------------------------------------- */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();


  /* ---------------------------------------------------
     2. MENU MOBILE (HAMBURGER ☰ / ✕)
  --------------------------------------------------- */
  const menuToggle = document.getElementById('menuToggle');
  const primaryNav = document.getElementById('primary-nav');

  if (menuToggle && primaryNav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('is-open');
      menuToggle.classList.toggle('is-active', isOpen);
      menuToggle.setAttribute('aria-expanded', String(isOpen));
      menuToggle.textContent = isOpen ? '✕' : '☰';
    });

    primaryNav.querySelectorAll('.nav__link').forEach((link) => {
      link.addEventListener('click', () => {
        primaryNav.classList.remove('is-open');
        menuToggle.classList.remove('is-active');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.textContent = '☰';
      });
    });
  }


  /* ---------------------------------------------------
     3. MODE TAMPILAN (THEME TOGGLE)
     Catatan: tombol #themeToggle belum ada di HTML,
     jadi blok ini otomatis diabaikan (aman, tidak error).
  --------------------------------------------------- */
  const themeToggle = document.getElementById('themeToggle');
  const themeLabel = themeToggle ? themeToggle.querySelector('.theme-toggle__label') : null;
  const themeIcon  = themeToggle ? themeToggle.querySelector('.theme-toggle__icon')  : null;
  const STORAGE_KEY = 'portfolio-theme';

  function applyTheme(theme) {
    if (theme === 'print') {
      document.documentElement.setAttribute('data-theme', 'print');
      if (themeLabel) themeLabel.textContent = 'Mode Biru';
      if (themeIcon)  themeIcon.textContent  = '◑';
    } else {
      document.documentElement.removeAttribute('data-theme');
      if (themeLabel) themeLabel.textContent = 'Mode Cetak';
      if (themeIcon)  themeIcon.textContent  = '◐';
    }
  }

  let savedTheme = 'blueprint';
  try { savedTheme = localStorage.getItem(STORAGE_KEY) || 'blueprint'; } catch (e) {}
  applyTheme(savedTheme);

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') === 'print' ? 'print' : 'blueprint';
      const next    = current === 'print' ? 'blueprint' : 'print';
      applyTheme(next);
      try { localStorage.setItem(STORAGE_KEY, next); } catch (e) {}
    });
  }


  /* ---------------------------------------------------
     4. (dihapus)
     Sebelumnya di sini ada kode animasi "ketik" yang
     memanggil variabel `typedEl` dan `roles` yang tidak
     pernah didefinisikan. Ini menyebabkan ReferenceError
     saat halaman dimuat, yang menghentikan SEMUA kode
     JavaScript setelahnya (menu aktif saat scroll,
     animasi angka, animasi skill bar, filter proyek,
     validasi form, scroll reveal, tombol kembali ke atas).
     Blok itu sudah dihapus supaya situs berjalan normal.
  --------------------------------------------------- */


  /* ---------------------------------------------------
     5. NAVIGASI AKTIF SAAT SCROLL
  --------------------------------------------------- */
  const sections = document.querySelectorAll('main section[id]');
  const navLinks = document.querySelectorAll('.nav__link');

  if (sections.length && navLinks.length && 'IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          navLinks.forEach((link) => {
            link.classList.toggle('active-link', link.getAttribute('href') === `#${id}`);
          });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });
    sections.forEach((section) => navObserver.observe(section));
  }


  /* ---------------------------------------------------
     6. ANIMASI HITUNG ANGKA (HERO STATISTIK)
  --------------------------------------------------- */
  const counters = document.querySelectorAll('.hero__meta-num');

  function animateCounter(el) {
    const target   = parseInt(el.getAttribute('data-count'), 10) || 0;
    const duration = 1200;
    const start    = performance.now();
    function step(now) {
      const progress = Math.min((now - start) / duration, 1);
      el.textContent = Math.floor(progress * target);
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = target;
    }
    requestAnimationFrame(step);
  }

  if (counters.length && 'IntersectionObserver' in window) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { animateCounter(entry.target); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.6 });
    counters.forEach((el) => counterObserver.observe(el));
  } else {
    counters.forEach((el) => { el.textContent = el.getAttribute('data-count'); });
  }


  /* ---------------------------------------------------
     7. ANIMASI BATANG KEAHLIAN
  --------------------------------------------------- */
  const skillBars = document.querySelectorAll('.bar span');

  if (skillBars.length && 'IntersectionObserver' in window) {
    const barObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.4 });
    skillBars.forEach((bar) => barObserver.observe(bar));
  } else {
    skillBars.forEach((bar) => bar.classList.add('is-visible'));
  }


  /* ---------------------------------------------------
     8. FILTER PROYEK
  --------------------------------------------------- */
  const filterButtons  = document.querySelectorAll('.filter__btn');
  const projectCards   = document.querySelectorAll('.project-card');
  const projectsEmpty  = document.getElementById('projectsEmpty');

  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const filterValue = btn.getAttribute('data-filter');
      filterButtons.forEach((b) => { b.classList.remove('is-active'); b.setAttribute('aria-selected', 'false'); });
      btn.classList.add('is-active');
      btn.setAttribute('aria-selected', 'true');

      let visibleCount = 0;
      projectCards.forEach((card) => {
        const matches = filterValue === 'all' || card.getAttribute('data-category') === filterValue;
        card.classList.toggle('is-hidden', !matches);
        if (matches) visibleCount++;
      });
      if (projectsEmpty) projectsEmpty.hidden = visibleCount !== 0;
    });
  });


  /* ---------------------------------------------------
     9. VALIDASI FORMULIR KONTAK
  --------------------------------------------------- */
  const contactForm = document.getElementById('contactForm');
  const formSuccess = document.getElementById('formSuccess');

  if (contactForm) {
    const fields = {
      name:    { el: document.getElementById('name'),    message: 'Nama wajib diisi (minimal 3 karakter).' },
      email:   { el: document.getElementById('email'),   message: 'Masukkan alamat email yang valid.' },
      subject: { el: document.getElementById('subject'), message: 'Subjek wajib diisi.' },
      message: { el: document.getElementById('message'), message: 'Pesan wajib diisi (minimal 10 karakter).' }
    };
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    function setError(key, message) {
      const field   = fields[key];
      const errorEl = contactForm.querySelector(`[data-error-for="${key}"]`);
      if (message) { field.el.classList.add('is-invalid');    if (errorEl) errorEl.textContent = message; }
      else         { field.el.classList.remove('is-invalid'); if (errorEl) errorEl.textContent = ''; }
    }

    function validateField(key) {
      const value = fields[key].el.value.trim();
      switch (key) {
        case 'name':    if (value.length < 3)              return setError(key, fields[key].message), false; break;
        case 'email':   if (!emailPattern.test(value))     return setError(key, fields[key].message), false; break;
        case 'subject': if (value.length === 0)            return setError(key, fields[key].message), false; break;
        case 'message': if (value.length < 10)             return setError(key, fields[key].message), false; break;
      }
      setError(key, '');
      return true;
    }

    Object.keys(fields).forEach((key) => {
      fields[key].el.addEventListener('blur',  () => validateField(key));
      fields[key].el.addEventListener('input', () => { if (fields[key].el.classList.contains('is-invalid')) validateField(key); });
    });

    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      let isValid = true;
      Object.keys(fields).forEach((key) => { if (!validateField(key)) isValid = false; });
      if (!isValid) { if (formSuccess) formSuccess.hidden = true; return; }
      if (formSuccess) formSuccess.hidden = false;
      contactForm.reset();
      Object.keys(fields).forEach((key) => setError(key, ''));
    });
  }


  /* ---------------------------------------------------
     10. SCROLL REVEAL
  --------------------------------------------------- */
  const revealTargets = document.querySelectorAll(
    '.about__text, .about__panel, .skill-card, .project-card, .timeline__item, .contact-form, .contact-info'
  );
  revealTargets.forEach((el) => el.setAttribute('data-reveal', ''));

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.15 });
    document.querySelectorAll('[data-reveal]').forEach((el) => revealObserver.observe(el));
  } else {
    document.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-visible'));
  }


  /* ---------------------------------------------------
     11. TOMBOL "KEMBALI KE ATAS"
  --------------------------------------------------- */
  const backToTop = document.getElementById('backToTop');
  if (backToTop) {
    backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

});


/* =========================================================
   MODAL SERTIFIKAT
   Fungsi global — dipanggil dari onclick di HTML
   ========================================================= */
function openCertificate(src) {
  document.getElementById('certificateModal').style.display = 'flex';
  document.getElementById('certificateImage').src = src;
}

function closeCertificate() {
  document.getElementById('certificateModal').style.display = 'none';
}

window.onclick = function(event) {
  const modal = document.getElementById('certificateModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
};